# For this level check the CodeQL alerts produced by GitHub code scanning.

# Enable CodeQL [Text]: https://github.co/3rOmI2k
# Enable CodeQL [Video]: https://youtu.be/MdRvrbExaFk
# Learn more: https://codeql.github.com/

# Is it enough though for the code to be 100% secure? ;)